document.addEventListener('DOMContentLoaded', function() {
    const main = document.getElementById('main');
    if (!main) return;

    const blocks = main.querySelectorAll(':scope > div');
    const navLinks = document.querySelectorAll('[data-link]');
    
    function updateActiveLink(activeId) {
        navLinks.forEach(link => {
            if (link.dataset.link === activeId) {
                link.classList.add('is-active');
            } else {
                link.classList.remove('is-active');
            }
        });
    }

    function showBlock(targetId) {
        blocks.forEach(child => {
            child.style.display = 'none';
            child.classList.remove('fadeDown');
        });

        updateActiveLink(targetId);

        const target = document.getElementById(targetId);
        if (target && target.parentElement === main) {
            target.style.display = 'block';
            void target.offsetWidth; 
            target.classList.add('fadeDown');
            target.addEventListener('animationend', () => {
                target.classList.remove('fadeDown');
            }, { once: true });
        }
    }

    const urlParams = new URLSearchParams(window.location.search);
    const pathParam = urlParams.get('path');
    const targetElement = pathParam ? document.getElementById(pathParam) : null;
    const initialId = (targetElement && targetElement.parentElement === main) ? pathParam : 'home.main';

    showBlock(initialId);

    navLinks.forEach(el => {
        el.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.dataset.link;
            showBlock(targetId);
        });
    });
});